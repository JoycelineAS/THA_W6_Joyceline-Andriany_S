﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wordle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int lives;
            bool isInt = Int32.TryParse(tbLive.Text, out lives);
            if (!isInt)
            {
                MessageBox.Show("Number of tries must be numeric!");
                return; 
            }
            if (lives < 3)
            {
                MessageBox.Show("Number of tries must be larger or equal than 3");
                return;
            }


            Form_Play form_Play = new Form_Play(lives);
            form_Play.ShowDialog();

        }
    }
}
